#include <iostream>
#include <vector>
#include <string>
#include <map>
#include "master.h""
using namespace std;

int main()
{
	Q1();
	Q2();
	Q3();
	Q4();
	Q5();
	Q6();
	Q7();
	Q8();
	Q9();

	return 0;
}